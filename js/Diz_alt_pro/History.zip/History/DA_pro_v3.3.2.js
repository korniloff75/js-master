/******************************************
Copyright KorniloFF-ScriptS ©
http://kpa-ing.ru
*******************************************/
/*
<?php
header('content-type: application/x-javascript');
require_once 'js.php';
ob_start("compress_js");
?>
*/
"use strict";
var DizSel= DizSel || {
	version: '3.3.2', v:{ch:0}, log:[],
	checkUrl: /kpa\-ing/.test(location.host)? '/': '//kpa-ing.ru/',
	SlabovidButtonParent: _K.body(), //== Объект для вставки кнопки - default
	
	addons: {},
	sts: {sound:{}},
	Backup: {
		altObj: _K.body().cr('div',{ id:'altObj', style:'position:absolute; left:0; top:0; z-index:30000; width:100%; display:none; padding:20px; margin:0;'}),
		altBody: this.altObj.cr('div',{id:'altBody'}),
		save: function() {  
			//== Запоминаем размеры
			DizSel.fns.getNodes ( function(i) { i.setAttribute('fsIsh', Math.max(DizSel.sts.fontSize.min, parseInt(getComputedStyle(i).fontSize))) }, this.obj);
			[].forEach.call(this.obj.childNodes, function(i) {DizSel.Backup.altBody.Clone(i)});
			[].forEach.call(_K.G('A$div#altObj .DA_del' ), function(i) {i.del()});
			DizSel.fns.getNodes (function(i) {DizSel.fns.setCol(i); DizSel.fns.setFS(i) }); //== Сохранение начального размера 
		}, 
		obj: _K.G('$body' ) 
	},
	
	init: function() { 
		console.assert(_K.isObject(), '_K= ' + typeof(_K));
		if(!_K.prot || !!_K.v.diz )  return;
		Object.defineProperty(DizSel, 'urlBG', {value:DizSel.checkUrl+ 'css/Slabovid_PRO_v3/'})
		DizSel.linki= _K.G('|link');
		//== Создаем ссылки на основной и добавочный стили и кнопку смены дизайна
			DizSel.style_BG= (DizSel.linki[DizSel.linki.length-1] || _K.G('$head')).cr('link',{href: DizSel.urlBG+ 'Uni_3.css', rel:'StyleSheet',type:'text/css'},'after').cr('link',{href: '', rel:'StyleSheet',type:'text/css'},'after');
		//== 
		DizSel.createBGs();
		//	console.profile();
		DizSel.v.start= new Date();
		DizSel.CheckCook();
		DizSel.v.speed= new Date().getTime()-DizSel.v.start.getTime();
		//== 
		//	console.profileEnd();
		DizSel.log.push('Скорость отработки скрипта - ' + DizSel.v.speed + ' мс');
		if(_K.G('#speedScr')) _K.G('#speedScr',DizSel.v.speed.toString());
		console.info('Diz_alt_pro LOG: \n-------------------------\n'+DizSel.log.join('\n'));
	},
	addStyleSheet: function() {
		if(Cook.get('diz_alt')==='y') {Cook.set({diz_alt:'n'},30) ; } // location.reload(); //== Не удалось вернуть локальные стили цвета
		else {Cook.set({diz_alt:'y'},30); }; 
		DizSel.CheckCook();
	},
	PUopacity: function() { //== Анимация прозрачности ПУ
		_K.animate.stop=false;
		DizSel.v.animate= setTimeout(function() {
		//	_K.G(DizSel.PU ).Animate(9,1, 3000, function() {this.style.opacity= arguments[0]/10});
			_K.animate.init(9,1, 3000, function() {DizSel.PU.style.opacity= arguments[0]/10});
		},1000);
	},
	
	CheckCook: function() { //== При загрузке и КАЖДОМ КЛИКЕ на SlabovidButton
		DizSel.v.DAlt= Cook.get('diz_alt')==='y'; //== кешируем diz_alt
		this.SlabovidButton.value= this.SlabovidButton.title= this.sts.button.value();
		
		////////////////////////////////////////
		//== если выбран ДИЗАЙН Д/СЛАБОВИДЯЩИХ
		_K.d.show(DizSel.Backup.altObj);
		if(DizSel.v.DAlt) { 
			//== Исходный цвет текста
			this.changeCol.value= Cook.get('diz_alt_Col') || DizSel.sts.startCol()
		//	Cook.set({diz_alt_Col: this.changeCol.value});
			DizSel.Backup.altBody.className= Cook.get('diz_alt_class')||'';
			DizSel.style_BG.href= DizSel.urlBG+ (Cook.get('diz_alt_BG') || 'cs-white') +'.css'; //== Назначаем заданный фон
			
			if(!!_K.G('#puzadpn')) { //== Проверяем не Юкоз ли это? Выставляем отступ контента
				this.PU.style.top= parseInt(getComputedStyle(_K.G('#puzadpn')).height)*1.2+'px'; 
				_K.body().style.paddingTop= +(this.PU.style.top)*1.1+ parseInt(getComputedStyle(DizSel.PU).height)+'px';
			// DizSel.log.push(getComputedStyle(_K.G('#puzadpn')).height);
DizSel.log.push('getComputedStyle(_K.G(\'#puzadpn\')).height= '+(getComputedStyle(_K.G('#puzadpn')).height || 'нету'));
			} else if(_K.G('#wpadminbar' )) { //== Проверяем не ВП ли это? Выставляем отступ контента
				this.PU.style.top= getComputedStyle(_K.G('wpadminbar')).height;
			} else DizSel.Backup.altObj.style.paddingTop= (parseInt(getComputedStyle(DizSel.PU).height) || 45) + 'px';
DizSel.log.push('getComputedStyle(DizSel.PU).height= '+getComputedStyle(DizSel.PU).height);			
			
			// Украшательства ПУ
			_K.G(DizSel.PU,{display:'', opacity:.9})
			DizSel.PU.onmouseover= function() {
				if(!!DizSel.v.animate) clearTimeout(DizSel.v.animate); 
				_K.animate.stop=true;
				DizSel.PU.style.opacity=1;
			}
			DizSel.PU.onmouseout= DizSel.PUopacity;
			
			
		//////////////////////////////////	
		//== если СТАНДАРТНЫЙ ДИЗАЙН
		} else if(!DizSel.v.DAlt) { 
			_K.d.hide(DizSel.Backup.altObj);
			_K.animate.stop=true;
			
			if(!!_K.G('#puzadpn')) DizSel.SlabovidButton.style.margin= getComputedStyle(_K.G('#puzadpn')).height+' auto -'+ getComputedStyle(_K.G('#puzadpn')).height;
			if(!!_K.G('#uzadpn')) DizSel.SlabovidButton.style.position='relative';
			
		} //== /DizSel.v.DAlt
		
		DizSel.regRu(); //== Проверяем хостинг reg.ru
	},
	noFA: function() {
		FA= ['DIV_DA_207850_wrapper'];
		FA.forEach(function(el) {_K.d.hide(_K.G(el ))});
	},
	regRu: function() {
		var rRH= _K.G('$#header-content-inner div' );
		DizSel.log.push('rRH= '+ rRH);
		if (!rRH || !Check.re(/widget/i,rRH.id)) return;
		DizSel.log.push('Ага, значит сайт на хосте REG.RU');
		if(DizSel.v.DAlt) _K.G(rRH, {height:0} );
		else _K.G(rRH, {height:''} );
	},
	
	///////////////////////////////////////////////////////
	fns: { //== Вложенные ФУНКЦИИ	
		getNodes: function getNodesSelf(handler, els) { //== Метод увеличения/уменьшения кегля
			els= (els || DizSel.Backup.altBody).childNodes; 
			for (var i in els) {
				if ( !els.hasOwnProperty(i) || !_K.fns.in_array([1],els[i].nodeType) || Check.re(/no-size/i,els[i].className) || els[i].tagName && Check.re(DizSel.sts.fontSize.NoTags,els[i].tagName)) continue; //== Выкидываем ненужные Ноды, классы и теги
				handler(els[i]);
				 //== Каждому родителю текстового блока назначаем стиль
				if(els[i].hasChildNodes()) { getNodesSelf (handler, els[i]) } //== Остаются теги. Если есть потомки - рекурсия
			};
		},
		
		setCol: function(i) { i.style.color= Cook.get('diz_alt_Col') || DizSel.sts.startCol(); },  // if (DizSel.v.DAlt)
		setFS: function (i) { 
			i.fsIsh= +(i.fsIsh || Math.max(i.getAttribute('fsIsh'), DizSel.sts.fontSize.min));
			i.fs= i.fsIsh + DizSel.sts.fontSize.step * (+Cook.get('diz_alt_fs'));   
		//	console.log("i.fsIsh= "+ i.fsIsh);
			i.style.fontSize= i.fs+'px';
		},
		toggleStyle: function (stName) {
			DizSel.Backup.altBody.classList.contains(stName)? DizSel.Backup.altBody.classList.remove(stName) : DizSel.Backup.altBody.classList.add(stName);
			Cook.set([['diz_alt_class',DizSel.Backup.altBody.className]],5); 
		},
		
		imageOff: function () {
			for (var i=0, imgs= DizSel.Backup.altBody.querySelectorAll('img'), l= imgs.length; i < l; i++) {
				var imgSize= getComputedStyle(imgs[i]);
				if(parseInt(imgSize.width) < DizSel.sts.imageOff.minImg || imgs[i].id==='captcha') continue;
				imgs[i].def= imgs[i].def || imgs[i].src;
				
				if ( !imgs[i].alter) { //== Ч/Б
				//	imgs[i].alter= Cook.get('diz_alt_Img');
					imgs[i].alter= 0;
					imgs[i].style.filter= imgs[i].style.WebkitFilter= 'grayscale(100%)'; 
					imgs[i].alter++; continue;
				} else if (imgs[i].alter===1) { //== ALT
					_K.d.hide(imgs[i]); 
					_K.G(imgs[i], {filter:'grayscale(0)', WebkitFilter:'grayscale(0)'} ); 
					var s= _K.G(imgs[i] ).cr('span', {class:'imgAlt', style:'padding:3px;border:1px solid;display: inline-block; width:'+imgSize.width+'; height:'+imgSize.height} , 'after');
					s.innerHTML= imgs[i].alt || 'IMG';
					imgs[i].alter++; continue;
				} else if (imgs[i].alter===2) { //== NONE
					[].forEach.call(_K.G('A$span.imgAlt' ), function(a) {a.del()});
					imgs[i].alter++; continue;
				} else if (imgs[i].alter===3) { //== DEFAULT
					_K.d.show(imgs[i]);
					_K.G(imgs[i], {}, {src:imgs[i].def} ).alter=0; 
					continue;
				}
				
			};
			
		},
		sound: function() {
			function addSts (t) {
				setTimeout(function() {
					ya.speechkit.settings.apikey = '92c24be9-c348-4c66-8086-33a1327a077b';
					ya.tts = new ya.speechkit.Tts( DizSel.sts.sound );
				}, (t||0)+ 300)
			}
			if(!window.ya) _K.G('$head').cr('script',{type:'text/javascript', src:'https://webasr.yandex.net/jsapi/v1/webspeechkit.js'})
				.onload= function() { try { addSts() } catch (e) { addSts(300) }};
			
			DizSel.Backup.altBody.onmouseup = function(e) {
				e=_K.Event.fix(e);
				var selNode = window.getSelection().toString() ;// anchorNode.textContent
				if(e.target.nodeName==='CODE' || !selNode) return;
				console.log("проигрывается= "+ selNode);
				return ya.tts.speak(selNode);
			}
			_K.G(this, {boxShadow: '0 0 1px 1px #999', transform: 'scale(1.2)'} )

		},
		
		stylePU: function(el,set) { //== Украшаем ПУ стилями css3
			set= set || {opacity:.1, scale:.5 };
			el.style.opacity=set.opacity; 
		},
		zoom: function() { //== Разработка
			var base, baseZoom;
			function baseInit () {
				base= this.innerHTML;
				baseZoom= _K.G('$body' ).cr('div',{class:'zoomDiv'});
				baseZoom.innerHTML= base;
			}
		}
	}, //== /fns
	
	SaveFS: function (ch) { //== Сохраняем количество изменений размера шрифта
		if(!isNaN(ch)) {
			DizSel.v.ch= ch;
			var Next= +(Cook.get('diz_alt_fs') || 0)+ Math.sign(ch);  
			if(!DizSel.sts.fontSize.fixed) { //== Если размер итерационный
				if(!(Math.abs(Next)>DizSel.sts.fontSize.iter)) Cook.set({diz_alt_fs: Next},100); 
			} else Cook.set({diz_alt_fs: Math.sign(ch)},100);
			DizSel.fns.getNodes (DizSel.fns.setFS);
		} 
	},
	
/////////////////////////////////////////////////////////////
	createBGs: function() { //== Запускается ПРИ ЗАГРУЗКЕ //////
		//== Backup content /////////////////////////////////
			DizSel.Backup.save();
		//== Создаем БЛОК УПРАВЛЕНИЯ
			//== Создаем фрагмент ПУ
			DizSel.PUfr= _K.G(document.createDocumentFragment() );
			DizSel.PU= _K.G(DizSel.PU || DizSel.PUfr.cr('div',{id:'special-panel',class:'no-size center', style:"display:none; opacity:.9; /* height:47px; */"}) );
			DizSel.PU.event().add('select', function(e) {_K.Event.fix(e).preventDefault()});
			//== Создаем кнопку, если ее еще нет
			DizSel.SlabovidButton= DizSel.SlabovidButton || _K.G(DizSel.SlabovidButtonParent ).cr("input",{type:'button',class:'imgPU no-size btn DA_del', /*  sticky */style:'padding: 1px 5px 1px 50px; margin:0 auto; font-size:20px; background: #9dd1ff url("' + DizSel.urlBG + DizSel.sts.button.image + '") no-repeat 3px center; border-radius:5px; z-index:21000; position:static; left:5px; top:20px; cursor:pointer;', id:'diz_alt', value:'ДЛЯ СЛАБОВИДЯЩИХ'} ,"fCh");
			DizSel.SlabovidButton.event().add("click",DizSel.addStyleSheet);
			if(typeof DizSel.sts.button.callback==='function') DizSel.sts.button.callback() ;
			//== Создаем БЛОК КНОПОК СМЕНЫ ФОНА
			this.v.BG= this.v.BG || DizSel.PU.cr('div',{class:'no-size'}) ;
			DizSel.v.BG.cr('div',{style:'position: absolute; right: 0;'}).innerHTML= 'v '+ DizSel.version;
			DizSel.changeCol= DizSel.v.BG.cr('input',{type:'color',class:'imgPU',title:'цвет ТЕКСТА',style:'width:50px;height:30px;margin:0 20px;padding:0;', value: Cook.get('diz_alt_Col') || DizSel.sts.startCol()});
		//	console.info('= '+ (Cook.get('diz_alt_Col') || '#117'));
			//== Кукисы прописывать отдельно!
			for (var i in DizSel.sts.BG_dim) {
				var fn= (function(bg) { return function() { Cook.set({diz_alt_BG:bg },3); Cook.set({diz_alt_Col:DizSel.sts.startCol()},3); DizSel.CheckCook(); DizSel.fns.getNodes(DizSel.fns.setCol); }})(i), // NE
				
				a= { ppts:{src:i+ '.png', title:DizSel.sts.BG_dim[i]}, e:fn, st:{margin:'0 5px'} } ;
				nextPU.call(a);
			};
			

			//== Создаем кнопки увеличения/уменьшения/кернинга/сброса font-size
			var elsPU= {
				fontSizeS: { ppts:{src:'fontBig.png', title:'Уменьшить'}, e:function() {DizSel.SaveFS(-DizSel.sts.fontSize.step); }, st:{marginLeft:'20px'}},
				fontSizeB: { ppts:{ src:'fontBig.png', title:'Увеличить'}, e:function() {DizSel.SaveFS(DizSel.sts.fontSize.step); }, st:{width:'60px'}},
				fontType: { ppts:{ src:'text.png', title:'Тип шрифта'}, e:DizSel.fns.toggleStyle.bind(null,'fontType')},
				kern: {ppts:{src:'kern.png',title:'Изменить интервал'}, e:DizSel.fns.toggleStyle.bind(null, 'kern')},
				lh: {ppts: {src:'kern.png',title:'Высота строки'}, e: DizSel.fns.toggleStyle.bind(null, 'lineHeight'), st:{ transform: 'rotate(90deg)'}},
				imageOff: {ppts: {src:'imageOff.png',title:'Показ изображений',alt:'Показ изображений'}, e:DizSel.fns.imageOff},
				sound: {ppts: {src:'sound.png',title:'Озвучивать выделенный текст',alt:'Озвучивать выделенный текст'}, e:DizSel.fns.sound},
			//	fontRes: {ppts: {src:'reset.png', title:'Сбросить'}, e:function() { return DizSel.SaveFS('reset') }},
				toDefault: {ppts: {src:'toDefault.png', title:'Обычный вид', id:'toDefault'}, e:function() { DizSel.addStyleSheet(); }, st:{margin:'3px 20px 0'}},
			};
			
			DizSel.changeCol.onchange= function() { //== Цвет текста
				Cook.set({diz_alt_Col: this.value},50); 
				DizSel.fns.getNodes(DizSel.fns.setCol);
			};
			
			function nextPU (n) {
				var o= !!n? this[n]: this;
				o.ppts.src= DizSel.urlBG + o.ppts.src;
				o.ppts.class= 'imgPU';
				var i= DizSel.v.BG.cr('img',o.ppts);
				i.draggable=false;
				if(!!o.e) i.onclick= o.e;
				if(!!o.st) _K.G(i, o.st);
			}
			for (var i in elsPU) nextPU.call(elsPU, i);
			
			//== Вставляем фрагмент в DOM
			DizSel.Backup.altObj.append(DizSel.PUfr,"fCh");
			
		//== Создаем БЛОК УПРАВЛЕНИЯ - Конец
		
		
		if(DizSel.v.DAlt) DizSel.PUopacity(); 
		
	}, //== /createBGs
	
} //== /DizSel
if(!window.oldStable) {
	DizSel.addons.puny= _K.G('$head' ).cr('script', {src: DizSel.checkUrl + 'scripts/punycode.js', async:0});
	DizSel.addons.db= _K.G('$head' ).cr('script',{src: DizSel.checkUrl +'js/Diz_alt_pro/db?req='+_K.fns.rnd(0,1e5), async:0});
	if(/bereghost\.ru/.test(DizSel.host)) DizSel.noFA();
	_K.Event.add(window,'load',DizSel.init );
} 